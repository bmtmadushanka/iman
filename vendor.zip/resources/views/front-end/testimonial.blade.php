@include('front-end/inc/header')

<div id="page-banner" class="page-banner faq-banner container-fluid no-padding">
	<div class="page-heading">
		<h3>Testimonials</h3>
		<ol class="breadcrumb">
			<li><a href="#">Home</a></li>
			<li class="active"><a href="#">Testimonials</a></li>
		</ol>
	</div>
</div>



<div class="container-fluid no-padding blog">
    <div class="section-padding"></div>
    <div class="container">
        
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12 animated fadeInUp">
                <blockquote class="blockquote-reverse">
                    <p>Now the world do not move to the beat of just one drum what might be right for you may not be right for some makin their way the only way they know how that's just a little bit more than the law will allow wouldn't you like.</p>

                    <div class="testimonial-profile">

                        <img src="https://i.pinimg.com/originals/9d/53/6c/9d536c9dc08df0592de379418f820432.jpg" class="img-circle " alt="">

                    </div>
                    <footer><cite title="Source Title">Aabdeen Aabdeen</cite></footer>
                </blockquote>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-12 animated fadeInUp">
                <blockquote class="blockquote-reverse">
                    <p>Now the world do not move to the beat of just one drum what might be right for you may not be right for some makin their way the only way they know how that's just a little bit more than the law will allow wouldn't you like.</p>

                    <div class="testimonial-profile">

                        <img src="https://i.pinimg.com/originals/9d/53/6c/9d536c9dc08df0592de379418f820432.jpg" class="img-circle " alt="">

                    </div>
                    <footer><cite title="Source Title">Aabdeen Aabdeen</cite></footer>
                </blockquote>
            </div>
         
        </div>
    </div>
    <div class="section-padding"></div>
</div>



@include('front-end/inc/footer')